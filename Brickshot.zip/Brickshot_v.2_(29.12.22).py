#Разобраться с проблемой в статистике

import pygame as pg
import math
import sys
from random import randint
from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWidgets import QWidget, QLabel, QPushButton
from PyQt5 import uic
import sqlite3
import datetime


#Отслеживание исключений
def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


start_game = False
file = open('important_info.txt', 'r')
lines = file.readlines()
file.close()


#Создание класса меню игры в PyQt5
class Menu(QMainWindow):
    def __init__(self):
        super(Menu, self).__init__()
        uic.loadUi('Menu.ui', self)
        self.statistic_button.clicked.connect(self.open_statistic)
        self.statistic_button.setIcon(QtGui.QIcon('trophy_icon.png'))
        self.statistic_button.setIconSize(QtCore.QSize(30, 30))
        self.options_button.clicked.connect(self.open_options)
        self.options_button.setIcon(QtGui.QIcon('options_icon.png'))
        self.options_button.setIconSize(QtCore.QSize(30, 30))
        self.start_button.clicked.connect(self.start)
        self.start = 0
        

    def open_statistic(self):
        try:
            self.login_window.close()
        except Exception:
            pass
        try:
            self.registration_window.close()
        except Exception:
            pass
        try:
            self.options_window.close()
        except Exception:
            pass
        self.statistic_window = Statistic()
        self.statistic_window.show()

    def open_options(self):
        try:
            self.login_window.close()
        except Exception:
            pass
        try:
            self.registration_window.close()
        except Exception:
            pass
        try:
            self.statistic_window.close()
        except Exception:
            pass

    def start(self):
        try:
            self.statistic_window.close()
        except Exception:
            pass
        try:
            self.options_window.close()
        except Exception:
            pass
        global lines
        if len(lines[1].split()) == 1:
            self.registration_window = Registration()
            self.registration_window.show()
        else:
            self.login_window = Login()
            self.login_window.show()

    def closeEvent(self, event):
        global start_game
        if self.start:
            start_game = self.start
        event.accept()


class Registration(Menu):
    def __init__(self):
        super().__init__()
        uic.loadUi('Registration.ui', self)
        self.pushButton.clicked.connect(self.check)
        self.lineEdit.textChanged.connect(self.refresh)
        self.lineEdit_2.textChanged.connect(self.refresh)

    def check(self):
        account = self.lineEdit.text()
        password = self.lineEdit_2.text()
        if len(password) * len(account) == 0:
            self.label_4.setText('Empty line')
            return None
        if not account.isalnum():
            self.label_4.setText('Name must be in alnum format')
            return None
        con = sqlite3.connect('Brickshot.sqlite')
        cur = con.cursor()
        result = cur.execute('''SELECT account FROM users''').fetchall()
        for i in result:
            if account == i[0]:
                self.label_4.setText('This name is alredy used')
                return None
        cur.execute('''INSERT INTO users(account, password)
        VALUES(?, ?);''', (account, password,))
        con.commit()
        time_info = str(datetime.datetime.now()).split()
        cur.execute('''INSERT INTO activity(dates, time)
        VALUES(?, ?);''', (time_info[0], time_info[1],))
        con.commit()
        cur.execute('''INSERT INTO records(score)
        VALUES(0);''')
        con.commit()
        con.close()
        global file, lines
        file = open('important_info.txt', 'w')
        file.write(lines[0])
        file.write('account: ' + account + '\n')
        file.write('password: ' + password)
        file.close()
        global ex
        ex.start = 1
        ex.close()
        self.close()

    def refresh(self):
        self.label_4.setText('REGISTRATION')


class Login(Menu):
    def __init__(self):
        super().__init__()
        uic.loadUi('Login.ui', self)
        self.pushButton_2.clicked.connect(self.check)
        self.lineEdit.textChanged.connect(self.refresh)
        self.lineEdit_2.textChanged.connect(self.refresh)

    def check(self):
        account = self.lineEdit.text()
        password = self.lineEdit_2.text()
        if len(password) * len(account) == 0:
            self.label_4.setText('Empty line')
            return None
        if not account.isalnum():
            self.label_4.setText('Name must be in alnum format')
            return None
        global lines
        if lines[1].rstrip().split()[1] != account.rstrip():
            self.label_4.setText('Is is not yours account')
            return None
        elif lines[2].rstrip().split()[1] != password.rstrip():
            self.label_4.setText('Wrong password')
            return None
        file.close()
        time_info = str(datetime.datetime.now()).split()
        con = sqlite3.connect('Brickshot.sqlite')
        cur = con.cursor()
        user_id = cur.execute('''SELECT id FROM users WHERE account = ? AND password = ?''', (account, password,)).fetchall()[0][0]
        cur.execute('''UPDATE activity SET dates = ?, time = ? WHERE id = ?''', (time_info[0], time_info[1], user_id)).fetchall()
        con.commit()
        con.close()
        global ex
        ex.start = 1
        ex.close()
        self.close()

    def refresh(self):
        self.label_4.setText('LOGIN')

        
class Statistic(Menu):
    def __init__(self):
        super().__init__()
        uic.loadUi('Statistic.ui', self)

        
#Создание класса для быстрого взаимодействия с каждым из мячей
class BallList:
    def __init__(self):
        #Создание списка всех мячей
        self.spis = []

    def append(self, elem):
        #Переопределение функции добавления в список данного класса
        self.spis += (elem,)

    def move(self):
        #Активация движения мячей и анимации поля с его объектами
        #Объявление глобальных переменных цвета фона, количества мячей и счёта
        global r, g, b, count_of_balls, result
        #Заливка экрана данными rgb
        screen.fill(pg.Color(r, g, b,))
        #Создание и выравнивание на экране вручную текствовой метки счёта
        font = pg.font.Font(None, 100)
        text = font.render(str(result), True, (25, 25, 25))
        screen.blit(text, (205 -  20 * len(str(result)), 200))
        #Создание текствовой метки количества мячей
        font = pg.font.Font(None, 30)
        if not self.spis:
            text = font.render(str(count_of_balls), True, (255, 255, 255))
            screen.blit(text, (8, 476))
        for i in self.spis:
            i.move()

    def __len__(self):
        #Переопределение функции возвращения длины списка данного класса
        return len(self.spis)

    def all_catched(self):
        #Метод проверки на то, что все мячи собраны
        a = 1
        for i in self.spis:
            a *= i.iscatched()
        return a

    def clear(self):
        #Очистка списка мячей
        self.spis = []


class Ball(BallList):
    def __init__(self, click_coords):
        #Инициализация класс мяча. На входе кортеж координат нажатия мышки
        #Присвоение мячу направление движения
        #(Справка: обозначение направления - стороны света на английском языке)
        #Например, nw: North-West (Северо-Запад)
        if click_coords[0] <= 200:
            self.direction = 'nw'
        else:
            self.direction = 'ne'
        self.catch = 0
        #Просчёт коэффициента наклона
        #Исключение варианта прямого выстрела. Он будет с минимальным наклоном влево
        #Сделано во избежание деления на ноль
        try:
            self.move_y = math.fabs((495 - click_coords[1]) / (200 - click_coords[0]))
        except Exception:
            self.move_y = math.fabs((495 - click_coords[1]) / (199 - click_coords[0]))
        #Ограничение по минимальному наклону выстрела
        if self.move_y < 0.3:
            self.move_y = 0.3
        #Корректировка скорости мяча в зависимости от угла наклона
        self.move_x = 0.5 / self.move_y
        if self.move_y > 9:
            self.move_x = self.move_x ** 0.8
        elif 9 >= self.move_y > 6:
            self.move_x = self.move_x ** 0.7
        elif 6 >= self.move_y > 0.5:
            self.move_x = self.move_x ** 0.6
        else:
            self.move_x = self.move_x ** 0.5
        self.move_y *= self.move_x
        #Присвоение мячу центральной стартовой позиции
        self.ball_position = (200, 495)

    def move(self):
        #Объявление глобальной переменной, являющейся списком всех мячей
        global ball_list
        #Пропуск действия движения, если мяч уже собран
        if self.catch:
            return None
        #Определения направление полёта мяча или того, что он тащится за кадр
        if self.ball_position[0] - 5 <= -1:
            self.direction = self.direction[0] + 'e'
            pg.mixer.Channel(len(ball_list) - 1).play(pg.mixer.Sound('Plus_ball.mp3'))
        if self.ball_position[0] + 5 >= 401:
            self.direction = self.direction[0] + 'w'
            pg.mixer.Channel(len(ball_list) - 1).play(pg.mixer.Sound('Plus_ball.mp3'))
        if self.ball_position[1] - 5 <= -1:
            self.direction = 's' + self.direction[1]
            pg.mixer.Channel(len(ball_list) - 1).play(pg.mixer.Sound('Plus_ball.mp3'))
        if self.ball_position[1] + 5 >= 501 and self.ball_position[0] > 0:
            self.direction = 'collection...'
        #Прикольная анимация уползания собранных мячей за кадр :)
        if self.direction == 'collection...':
            if self.ball_position[0] > 7:
                self.ball_position = (self.ball_position[0] - 2, self.ball_position[1],)
            else:
                self.catch = 1
        #Обработка движения в зависимости от направления мяча
        elif self.direction == 'nw':
            self.ball_position = (self.ball_position[0] - self.move_x, self.ball_position[1] - self.move_y,)
        elif self.direction == 'ne':
            self.ball_position = (self.ball_position[0] + self.move_x, self.ball_position[1] - self.move_y,)
        elif self.direction == 'sw':
            self.ball_position = (self.ball_position[0] - self.move_x, self.ball_position[1] + self.move_y,)
        elif self.direction == 'se':
            self.ball_position = (self.ball_position[0] + self.move_x, self.ball_position[1] + self.move_y,)
        #Отрисовка
        pg.draw.circle(screen, pg.Color('white'), self.ball_position, 5)

    def iscatched(self):
        #Функция проверки статуса окончания движения мяча
        return self.catch


class FigureList:
    #Создание класса для фигур аналогично мячам
    def __init__(self):
        self.spis = []

    def append(self, elem):
        self.spis += (elem,)

    def remove(self, n):
        #Переопределение точечного удаления объекта из списка
        self.spis = self.spis[:n:] + self.spis[n + 1::]


#Оригинальные способы попрощаться
bye_list = ['Bye-bye', 'Goodbye', 'Have a nice day, BrickshotUser :)',
            'Ciao!!', 'It seems like today is going to be an amazing day',
            'Good mood', 'Mrrmeeeow', 'Merry Christmas!']


class StartGameError(Exception):
    pass


app = QApplication(sys.argv)
ex = Menu()
ex.show()
app.exec_()
try:
    if not start_game:
        raise StartGameError
except:
    print('\n\n-' + bye_list[randint(0, len(bye_list) - 1)])
    sys.exit()
pg.init()
pg.display.set_caption('Brickshot')
r = 0
g = 0
b = 0
count_of_balls = 1
result = 0
clock = pg.time.Clock()
if __name__ == '__main__':
    size = width, height = 400, 500
    screen = pg.display.set_mode(size)
    screen.fill(pg.Color(r, g, b,))
    clock = pg.time.Clock()
    running = True
    ball_list = BallList()
    check = 0
    font = pg.font.Font(None, 30)
    text = font.render(str(count_of_balls), True, (255, 255, 255))
    screen.blit(text, (8, 476))
    font = pg.font.Font(None, 100)
    text = font.render(str(result), True, (25, 25, 25))
    screen.blit(text, (185, 200))
    font = pg.font.Font(None, 30)
    while running:
        if r > 0:
            r -= 1
            g -= 1
            b -= 1
        pg.mixer.set_num_channels(len(ball_list) * 4)
        if check:
            ball_list.move()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
            if event.type == pg.MOUSEBUTTONDOWN:
                ball_list.append(Ball(tuple(pg.mouse.get_pos())))
                check = 1
                count_of_balls += 1
        if ball_list.all_catched() and pg.mouse.get_focused():
            pg.mouse.set_visible(False)
            screen.fill(pg.Color(r, g, b,))
            font = pg.font.Font(None, 100)
            text = font.render(str(result), True, (25, 25, 25))
            screen.blit(text, (205 -  20 * len(str(result)), 200))
            font = pg.font.Font(None, 30)
            text = font.render(str(count_of_balls), True, (255, 255, 255))
            screen.blit(text, (8, 476))
            m_coords = tuple(pg.mouse.get_pos())
            pg.draw.line(screen, pg.Color((0, 100, 0,)), 
             m_coords,
             [200, 500], 5)
        #Экран, если идёт сборка мячей, а пользователь увёл мышку
        elif not pg.mouse.get_focused() and not ball_list.all_catched():
            pg.mouse.set_visible(True)
            screen.fill(pg.Color(r, g, b,))
            font = pg.font.SysFont('OCR A Extended', 72)
            text = font.render('BRICKSHOT', True, (255, 255, 0))
            screen.blit(text, (5, 200))
            font = pg.font.SysFont('OCR A Extended', 24)
            text = font.render('running...', True, (255, 255, 0))
            screen.blit(text, (130, 270))
        #Экран, если мячи собраны, а пользователь увёл мышку
        elif not pg.mouse.get_focused() and ball_list.all_catched():
            pg.mouse.set_visible(True)
            screen.fill(pg.Color(r, g, b,))
            font = pg.font.SysFont('OCR A Extended', 72)
            text = font.render('BRICKSHOT', True, (0, 255, 0))
            screen.blit(text, (5, 200))
            font = pg.font.SysFont('OCR A Extended', 24)
            text = font.render('completed', True, (0, 255, 0))
            screen.blit(text, (130, 270))
        if ball_list.all_catched() and len(ball_list) > 0:
            r = 255
            g = 255
            b = 255
            ball_list.clear()
            result += 1
        pg.display.flip()
        clock.tick(720)
    pg.quit()
