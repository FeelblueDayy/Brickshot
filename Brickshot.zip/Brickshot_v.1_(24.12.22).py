import pygame as pg

class BallList:
    def __init__(self):
        self.spis = []

    def append(self, elem):
        self.spis += (elem,)

    def move(self):
        global r, g, b, count_of_balls, result
        screen.fill(pg.Color(r, g, b,))
        font = pg.font.Font(None, 100)
        text = font.render(str(result), True, (25, 25, 25))
        if result < 10:
            screen.blit(text, (185, 200))
        elif result < 100:
            screen.blit(text, (170, 200))
        elif result < 1000:
            screen.blit(text, (150, 200))
        font = pg.font.Font(None, 30)
        if not self.spis:
            text = font.render(str(count_of_balls), True, (255, 255, 255))
            screen.blit(text, (8, 476))
        for i in self.spis:
            i.move()

    def __len__(self):
        return len(self.spis)

    def all_catched(self):
        a = 1
        for i in self.spis:
            a *= i.iscatched()
        return a

    def clear(self):
        self.spis = []


class Ball(BallList):
    def __init__(self, start):
        self.s = start
        self.t = 'nw'
        self.catch = 0

    def move(self):
        global ball_list
        if self.catch:
            return None
        if self.s[0] - 5 <= -1:
            self.t = self.t[0] + 'e'
            pg.mixer.Channel(len(ball_list) - 1).play(pg.mixer.Sound('Plus_ball.mp3'))
        if self.s[0] + 5 >= 401:
            self.t = self.t[0] + 'w'
            pg.mixer.Channel(len(ball_list) - 1).play(pg.mixer.Sound('Plus_ball.mp3'))
        if self.s[1] - 5 <= -1:
            self.t = 's' + self.t[1]
            pg.mixer.Channel(len(ball_list) - 1).play(pg.mixer.Sound('Plus_ball.mp3'))
        if self.s[1] + 5 >= 501 and self.s[0] > 0:
            self.t = 'collection...'
        if self.t == 'collection...':
            if self.s[0] > 7:
                self.s = (self.s[0] - 2, self.s[1],)
            else:
                self.catch = 1
        elif self.t == 'nw':
            self.s = (self.s[0] - 2, self.s[1] - 2,)
        elif self.t == 'ne':
            self.s = (self.s[0] + 2, self.s[1] - 2,)
        elif self.t == 'sw':
            self.s = (self.s[0] - 2, self.s[1] + 2,)
        elif self.t == 'se':
            self.s = (self.s[0] + 2, self.s[1] + 2,)
        pg.draw.circle(screen, pg.Color('white'), self.s, 5)

    def iscatched(self):
        return self.catch


class Figure:
    def __init__(self):
        self.spis = []

    def append(self, elem):
        self.spis += (elem,)

    def remove(self, n):
        self.spis = self.spis[:n:] + self.spis[n + 1::]


pg.init()
virtual_x = 0
virtual_y = 0
r = 0
g = 0
b = 0
count_of_balls = 1
result = 0
if __name__ == '__main__':
    size = width, height = 400, 500
    screen = pg.display.set_mode(size)
    screen.fill(pg.Color(r, g, b,))
    clock = pg.time.Clock()
    running = True
    ball_list = BallList()
    check = 0
    font = pg.font.Font(None, 30)
    text = font.render(str(count_of_balls), True, (255, 255, 255))
    screen.blit(text, (8, 476))
    font = pg.font.Font(None, 100)
    text = font.render(str(result), True, (25, 25, 25))
    screen.blit(text, (185, 200))
    font = pg.font.Font(None, 30)
    while running:
        if r > 0:
            r -= 1
            g -= 1
            b -= 1
        pg.mixer.set_num_channels(len(ball_list) * 4)
        if check:
            ball_list.move()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
            if event.type == pg.MOUSEBUTTONDOWN:
                ball_list.append(Ball(tuple(pg.mouse.get_pos())))
                check = 1
                count_of_balls += 1
        if ball_list.all_catched() and len(ball_list) > 0:
            r = 255
            g = 255
            b = 255
            ball_list.clear()
            result += 1
        pg.display.flip()
        clock.tick(250)
    pg.quit()
