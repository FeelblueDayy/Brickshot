#Исправить хитбоксы и жизни
import pygame as pg
import math
import sys
from random import randint, random, choice
from PyQt5 import QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QHeaderView,  QTableWidgetItem
from PyQt5.QtWidgets import QWidget, QLabel, QPushButton
from PyQt5 import uic
from PyQt5.QtGui import QPixmap
import sqlite3
import datetime
import os


#Отслеживание исключений
def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)

#Создание переменных, отвечающих за начало игры и текстовый файл с важными данными
start_game = False
file = open('important_info.txt', 'r')
lines = file.readlines()
file.close()


#Создание класса меню игры в PyQt5
class Menu(QWidget):
    def __init__(self):
        super(Menu, self).__init__()
        #Загрузка интерфейса и установление иконок на кнопки
        uic.loadUi('Menu.ui', self)
        self.statistic_button.clicked.connect(self.open_statistic)
        self.statistic_button.setIcon(QtGui.QIcon('trophy_icon.png'))
        self.statistic_button.setIconSize(QtCore.QSize(30, 30))
        self.options_button.clicked.connect(self.open_options)
        self.options_button.setIcon(QtGui.QIcon('options_icon.png'))
        self.options_button.setIconSize(QtCore.QSize(30, 30))
        self.start_button.clicked.connect(self.start)
        #Установка иконки окна
        self.setWindowIcon(QtGui.QIcon('Brickshot_icon.png'))
        gif = QtGui.QMovie('fireplace.gif')
        self.fire.setMovie(gif)
        gif.start()
        pixmap = QPixmap('background.png')
        self.back.setPixmap(pixmap)
        

    def open_statistic(self):
        #Открыть статистику, закрыв остальные окна
        try:
            self.login_window.close()
        except Exception:
            pass
        try:
            self.registration_window.close()
        except Exception:
            pass
        try:
            self.options_window.close()
        except Exception:
            pass
        self.statistic_window = Statistic()
        self.statistic_window.show()
        self.hide()

    def open_options(self):
        #Открыть настройки, закрыв остальные окна
        try:
            self.login_window.close()
        except Exception:
            pass
        try:
            self.registration_window.close()
        except Exception:
            pass
        try:
            self.statistic_window.close()
        except Exception:
            pass
        self.options_window = Options()
        self.options_window.show()
        self.hide()

    def start(self):
        #Открыть логин или регистрацию, закрыв остальные окна
        try:
            self.statistic_window.close()
        except Exception:
            pass
        try:
            self.options_window.close()
        except Exception:
            pass
        #Проверка на то, зарегистрирован ли пользователь в системе
        global lines
        if len(lines[1].split()) == 1:
            self.registration_window = Registration()
            self.registration_window.show()
        else:
            self.login_window = Login()
            self.login_window.show()
        self.hide()

    def keyPressEvent(self, event):
        if event.key() == 16777216:
            self.close()
        elif event.key() == 16777220:
            self.start_button.click()
        elif event.text() == 'q':
            self.statistic_button.click()
        elif event.text() == 'e':
            self.options_button.click()

    def mousePressEvent(self, event):
        self.start_button.click()


#Создание класса регистрации
class Registration(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('Registration.ui', self)
        self.pushButton.clicked.connect(self.check)
        self.lineEdit.textChanged.connect(self.refresh)
        self.lineEdit_2.textChanged.connect(self.refresh)
        #Установка иконки окна
        self.setWindowIcon(QtGui.QIcon('Brickshot_icon.png'))
        self.open_menu = 1

    def check(self):
        #Чтение введённого имени пользователя и пароля
        account = self.lineEdit.text()
        password = self.lineEdit_2.text()
        #Случай, если есть пустая строка
        if len(password) * len(account) == 0:
            self.label_4.setText('Empty line')
            return None
        #Случай, если имя состоит не только из букв и цифр
        if not account.isalnum():
            self.label_4.setText('Name must be in alnum format')
            return None
        #Подключение к базе данных
        con = sqlite3.connect('Brickshot.sqlite')
        cur = con.cursor()
        result = cur.execute('''SELECT account FROM users''').fetchall()
        #Проверка никнейма на уникальность
        for i in result:
            if account == i[0]:
                self.label_4.setText('This name is alredy used')
                return None
        #Запись данных о пользователе
        cur.execute('''INSERT INTO users(account, password)
        VALUES(?, ?);''', (account, password,))
        con.commit()
        #Запись последней даты и времени пользования
        time_info = str(datetime.datetime.now()).split()
        cur.execute('''INSERT INTO activity(dates, time)
        VALUES(?, ?);''', (time_info[0], time_info[1],))
        con.commit()
        #Установка значения рекорда 0
        cur.execute('''INSERT INTO records(score)
        VALUES(0);''')
        con.commit()
        con.close()
        #Запись данных для входа в файл important_info.txt
        global file, lines
        file = open('important_info.txt', 'w')
        file.write(lines[0])
        file.write('account: ' + account + '\n')
        file.write('password: ' + password)
        file.close()
        #Закрытие окна с запуском игры
        global start_game
        start_game = 1
        self.open_menu = 0
        self.close()

    def refresh(self):
        #Функция для сброса текстовой метки после ошибки при регистрации
        self.label_4.setText('REGISTRATION')

    def keyPressEvent(self, event):
        if event.key() == 16777216:
            self.close()
            self.menu_window = Menu()
            self.menu_window.show()
        elif event.key() == 16777237 and self.lineEdit.hasFocus():
            self.lineEdit_2.setFocus()
        elif event.key() == 16777235 and self.lineEdit_2.hasFocus():
            self.lineEdit.setFocus()

    def mousePressEvent(self, event):
        self.pushButton.click()

    def closeEvent(self, event):
        if self.open_menu:
            self.menu_window = Menu()
            self.menu_window.show()
        event.accept()


#Класс для входа в аккаунт, созданный наподобие класса регистрации
class Login(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('Login.ui', self)
        self.pushButton_2.clicked.connect(self.check)
        self.lineEdit.textChanged.connect(self.refresh)
        self.lineEdit_2.textChanged.connect(self.refresh)
        #Установка иконки окна
        self.setWindowIcon(QtGui.QIcon('Brickshot_icon.png'))
        self.open_menu = 1

    def check(self):
        account = self.lineEdit.text()
        password = self.lineEdit_2.text()
        if len(password) * len(account) == 0:
            self.label_4.setText('Empty line')
            return None
        if not account.isalnum():
            self.label_4.setText('Name must be in alnum format')
            return None
        #Проверка пренадлежности аккаунта по данным из файла important_info.txt
        global lines
        if lines[1].rstrip().split()[1] != account.rstrip():
            self.label_4.setText('Is is not yours account')
            return None
        #Проверка корректности пароля по данным из файла important_info.txt
        elif lines[2].rstrip().split()[1] != password.rstrip():
            self.label_4.setText('Wrong password')
            return None
        file.close()
        #Перезапись в базу информации об активности
        time_info = str(datetime.datetime.now()).split()
        con = sqlite3.connect('Brickshot.sqlite')
        cur = con.cursor()
        user_id = cur.execute('''SELECT id FROM users WHERE account = ? AND password = ?''', (account, password,)).fetchall()[0][0]
        cur.execute('''UPDATE activity SET dates = ?, time = ? WHERE id = ?''', (time_info[0], time_info[1], user_id)).fetchall()
        con.commit()
        con.close()
        #Запуск игры
        global start_game
        start_game = 1
        self.open_menu = 0
        self.close()

    def refresh(self):
        #Функция для сброса текстовой метки после ошибки при входе
        self.label_4.setText('LOGIN')

    def keyPressEvent(self, event):
        if event.key() == 16777216:
            self.close()
            self.menu_window = Menu()
            self.menu_window.show()
        elif event.key() == 16777237 and self.lineEdit.hasFocus():
            self.lineEdit_2.setFocus()
        elif event.key() == 16777235 and self.lineEdit_2.hasFocus():
            self.lineEdit.setFocus()
            
    def mousePressEvent(self, event):
        self.pushButton_2.click()

    def closeEvent(self, event):
        if self.open_menu:
            self.menu_window = Menu()
            self.menu_window.show()
        event.accept()


#Класс отображения статистики
class Statistic(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('Statistic.ui', self)
        self.me_button.clicked.connect(self.creator)
        self.top_button.clicked.connect(self.creator)
        #Установка иконки окна
        self.setWindowIcon(QtGui.QIcon('Brickshot_icon.png'))

    def creator(self):
        #Очистка таблицы и присвоение имени верхним заголовкам
        #Примечание. Боковые заголовки были скрыты в настройках Qt Designer'a
        self.table.clear()
        check = self.sender().text()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(['Score', 'User', 'id'])
        stylesheet = "::section{Background-color:rgb(0, 0, 0);}"
        self.table.horizontalHeader().setStyleSheet(stylesheet)
        font = QtGui.QFont()
        font.setFamily('OCR A Extended')
        font.setPointSize(14)
        self.table.horizontalHeader().setFont(font)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.resizeColumnsToContents()
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Fixed)
        self.table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.Fixed)
        con = sqlite3.connect('Brickshot.sqlite')
        cur = con.cursor()
        if check == 'SHOW TOP':
            result = cur.execute('''SELECT records.score, users.account, users.id FROM users, records
                 WHERE users.id = records.id ORDER BY records.score DESC, users.id ASC''').fetchall()
        else:
            global lines
            result = cur.execute('''SELECT records.score, users.account, users.id FROM users, records
                 WHERE users.id = records.id AND users.account = ? ORDER BY records.score DESC''', ((lines[1].rstrip().split()[1],))).fetchall()
            
        for i in range(len(result)):
            self.table.setRowCount(len(result))
            for j in range(len(result[i])):
                item = QTableWidgetItem(str(result[i][j]))
                item.setFlags(QtCore.Qt.ItemIsEnabled)
                self.table.setItem(i, j, item)
        con.close()

    def keyPressEvent(self, event):
        if event.key() == 16777216:
            self.close()
            self.menu_window = Menu()
            self.menu_window.show()

    def closeEvent(self, event):
        self.menu_window = Menu()
        self.menu_window.show()
        event.accept()


class Options(QWidget):
    def __init__(self):
        super().__init__()
        global lines
        uic.loadUi('Options.ui', self)
        self.clear_button.clicked.connect(self.sqclear)
        self.volume_button.setText(lines[0].upper())
        self.volume_button.clicked.connect(self.volume_switcher)

    def sqclear(self):
        con = sqlite3.connect('Brickshot.sqlite')
        cur = con.cursor()
        result = cur.execute('''SELECT * FROM activity''').fetchall()
        now = datetime.datetime.now()
        col = 0
        for i in result:
            then = datetime.datetime(int(i[1].split('-')[0]), int(i[1].split('-')[1]), int(i[1].split('-')[2]), int(i[2].split(':')[0]), int(i[2].split(':')[1]), int(i[2].split(':')[2][:2:]))
            difference = str(now - then)
            if 'days' in difference and int(difference.split('days')[0]) > 30:
                cur.execute('''UPDATE records SET score = 0 WHERE id = ?''', (i[0],)).fetchall()
                con.commit()
                col += 1
        if not col:
            self.label.setText('There is no one user to delete now')
        elif col == 1:
            self.label.setText('1 user has been deleted')
        else:
            self.label.setText('{} users has been deleted'.format(col))
        con.close()

    def volume_switcher(self):
        global lines
        if lines[0].split()[1] == 'on':
            new = 'volume: off\n'
        else:
            new = 'volume: on\n'
        file = open('important_info.txt', 'w')
        file.write(new)
        file.write(lines[1])
        file.write(lines[2])
        file.close()
        file = open('important_info.txt', 'r')
        lines = file.readlines()
        file.close()
        self.volume_button.setText(lines[0].upper())
        self.label.clear()

    def keyPressEvent(self, event):
        if event.key() == 16777216:
            self.close()
            self.menu_window = Menu()
            self.menu_window.show()
        self.label.clear()

    def closeEvent(self, event):
        self.menu_window = Menu()
        self.menu_window.show()
        event.accept()


class Ball:
    def __init__(self, click_coords):
        #Инициализация класс мяча. На входе кортеж координат нажатия мышки
        #Присвоение мячу направление движения
        self.catch = 0
        #Присвоение мячу центральной стартовой позиции
        self.ball_position = (200, 495)
        #Рассчёт угла наклона
        lenght = (abs(self.ball_position[0] - click_coords[0]) + self.ball_position[1] - click_coords[1]) ** 0.5
        self.move_y = (self.ball_position[1] - click_coords[1]) / lenght
        self.move_y = round(self.move_y.real) + round(self.move_y.imag)
        self.move_x = (self.ball_position[0] - click_coords[0]) / lenght
        self.move_x = round(self.move_x.real) + round(self.move_x.imag)
        self.move_x /= 2
        self.move_y /= 2
        if self.move_y < 0:
            self.move_y *= -1
            self.move_x *= -1
        if self.move_y < 2 and click_coords[0] >= 200:
            self.__init__((400, 437))
        elif self.move_y < 2 and click_coords[0] < 200:
            self.__init__((0, 437))
        self.direction = ''

    def move(self):
        #Пропуск действия движения, если мяч уже собран
        if self.catch:
            return None
        #Объявление глобальных переменных цвета фона, силы мяча и счёта
        global r, g, b, ball_power, result, lines, figurelist
        #Заливка экрана данными rgb
        screen.fill(pg.Color(r, g, b,))
        #Создание и выравнивание на экране вручную текствовой метки счёта
        font = pg.font.Font(None, 100)
        text = font.render(str(result), True, (255, 255, 0))
        screen.blit(text, (205 -  20 * len(str(result)), 200))
        #Создание текствовой метки силы мяча
        font = pg.font.Font(None, 30)
        text = font.render(str(ball_power), True, (255, 0, 0))
        screen.blit(text, (8, 476))
        #Создание звука
        sound = pg.mixer.Sound('Plus_ball.mp3')
        #Определения направления полёта мяча или того, что он тащится за кадр
        if round(self.ball_position[1] - self.move_y) > 500 and self.ball_position[0] > 0:
            self.direction = 'collection...'
            #Прикольная анимация уползания мяча за кадр
            if self.ball_position[0] > 5:
                if self.ball_position[1] > 500:
                    self.ball_position = (self.ball_position[0] - 2, self.ball_position[1] - 1,)
                else:
                    self.ball_position = (self.ball_position[0] - 2, self.ball_position[1],)
            else:
                self.catch = 1
        elif self.ball_position[0] > 0:
            self.direction = ''
            for i in range(len(figure_list)):
                if not i:
                    break
                obj = figure_list[i]
                if obj.type == 'boost':
                    if obj.center[0] - 5 <= round(self.ball_position[0] - self.move_x) <= obj.center[0] + 5 \
                     and obj.center[1] - 5 <= round(self.ball_position[1] - self.move_y) <= obj.center[1] + 5:
                        ball_power += 1
                        figure_list.pop(i)
                elif obj.type == 'square':
                    if round(self.ball_position[0] + 5 - self.move_x) >= obj.center[0] or round(self.ball_position[0] - 5 + self.move_x) <= obj.center[0] + 25:
                        self.move_x *= -1
                    if round(self.ball_position[1] + 5 - self.move_y) >= obj.center[1] or round(self.ball_position[1] - 5 + self.move_y) <= obj.center[1] + 25:
                        self.move_y *= -1
                    obj.hp -= ball_power
                    if obj.hp <= 0:
                        figure_list.pop(i)
        if 0 >= self.ball_position[0] - self.move_x or self.ball_position[0] - self.move_x >= 400:
            self.move_x *= -1
        if 0 >= self.ball_position[1] - self.move_y:
            self.move_y *= -1
        if not self.direction:
            self.ball_position = (self.ball_position[0] - self.move_x, self.ball_position[1] - self.move_y)
        #Отрисовка
        pg.draw.circle(screen, pg.Color('white'), self.ball_position, 5)

    def iscatched(self):
        #Функция проверки статуса окончания движения мяча
        return self.catch


#Оригинальные способы попрощаться
bye_list = ['Bye-bye', 'Goodbye', 'Have a nice day, BrickshotUser :)',
            'Ciao!!', 'It seems like today is going to be an amazing day',
            'Good mood', 'Mrrmeeeow']


class StartGameError(Exception):
    pass


class Sprite(pg.sprite.Sprite):
    def __init__(self, file):
        pg.sprite.Sprite.__init__(self)
        self.image = file
        self.rect = self.image.get_rect()
        self.rect.center = (0, 0)


class Figure:
    def __init__(self):
        self.center = (0, 0)

    def move(self):
        self.center = (self.center[0], self.center[1] + 25)


class Square(Figure):
    def __init__(self):
        global result
        super().__init__()
        self.type = 'square'
        self.start_hp = round(result ** result * 10 ** (len(str(result)) - 1))
        self.hp = self.start_hp

    def draw(self):
        pg.draw.rect(screen, (round(255 * self.start_hp / self.hp), 0, 0),
                     (self.center[0], self.center[1], 25, 25))
        pg.draw.rect(screen, (255, 255, 255),
                     (self.center[0], self.center[1], 25, 25), 1)


class Boost(Figure):
    def __init__(self):
        super().__init__()
        self.center = (self.center[0] + 25, self.center[1] + 25)
        self.type = 'boost'

    def draw(self):
        pg.draw.circle(screen, pg.Color('white'), self.center, 6)
        pg.draw.circle(screen, pg.Color('green'), self.center, 5)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pg.image.load(fullname)
    return image

def generations_count(result):
    chance_2 = result * 0.08
    chance_3 = result * 0.03
    chance_4 = result * 0.009
    chance_5 = result * 0.006
    chance_6 = result * 0.003
    chance_7 = result * 0.0009
    chance_8 = result * 0.0007
    chance_9 = result * 0.0005
    chance_10 = result * 0.0003
    chance_11 = result * 0.0001
    chance_12 = result * 0.00009
    chance_13 = result * 0.00007
    chance_14 = result * 0.00006
    chance_15 = result * 0.000055
    chance_16 = result * 0.00004
    chance_1 = 1 - sum([chance_2, chance_3, chance_4, chance_5, chance_6, chance_7, chance_8, chance_9,
                        chance_10, chance_11, chance_12, chance_13, chance_14, chance_15, chance_16])
    generation = random()
    if chance_16 - generation >= 0:
        return 16
    elif chance_15 - generation >= 0:
        return 15
    elif chance_14 - generation >= 0:
        return 14
    elif chance_13 - generation >= 0:
        return 13
    elif chance_12 - generation >= 0:
        return 12
    elif chance_11 - generation >= 0:
        return 11
    elif chance_10 - generation >= 0:
        return 10
    elif chance_9 - generation >= 0:
        return 9
    elif chance_8 - generation >= 0:
        return 8
    elif chance_7 - generation >= 0:
        return 7
    elif chance_6 - generation >= 0:
        return 6
    elif chance_5 - generation >= 0:
        return 5
    elif chance_4 - generation >= 0:
        return 4
    elif chance_3 - generation >= 0:
        return 3
    elif chance_2 - generation >= 0:
        return 2
    else:
        return 1

def generation(result):
    locallist = []
    positionlist = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    for i in range(generations_count(result)):
        position = choice(positionlist)
        positionlist.remove(position)
        if 0.2 - random() > 0:
            figure = Boost()
        else:
            figure = Square()
        figure.center = (position * 25, 0)
        locallist.append(figure)
    return locallist

    
app = QApplication(sys.argv)
ex = Menu()
while True:
    ex.show()
    app.exec_()
    try:
        if not start_game:
            raise StartGameError
    except:
        print('\n\n-' + bye_list[randint(0, len(bye_list) - 1)])
        sys.exit()
    pg.init()
    pg.display.set_caption('Brickshot')
    r = 0
    g = 0
    b = 0
    ball_power = 1
    result = 0
    clock = pg.time.Clock()
    size = width, height = 400, 500
    screen = pg.display.set_mode(size)
    screen.fill(pg.Color(r, g, b,))
    clock = pg.time.Clock()
    running = True
    check = 0
    font = pg.font.Font(None, 30)
    text = font.render(str(ball_power), True, (255, 255, 255))
    screen.blit(text, (8, 476))
    font = pg.font.Font(None, 100)
    text = font.render(str(result), True, (25, 25, 25))
    screen.blit(text, (185, 200))
    font = pg.font.Font(None, 30)
    pg.mixer.set_num_channels(4)
    ball = Ball((0, 0))
    ball.catch = True
    completed = 1
    image = load_image(['Tree_cursor.png', 'Custom_cursor1.png',
                        'Telegram_cursor.png', 'Custom_cursor2.png',
                        'Custom_cursor3.png', 'Custom_cursor4.png',
                        'Custom_cursor5.png', 'Custom_cursor6.png',
                        'Custom_cursor7.png', 'Custom_cursor8.png'][randint(0, 9)]).convert_alpha()
    cursor = Sprite(image)
    figure_list = []
    while running:
        if r > 0:
            r -= 3
            g -= 3
            b -= 3
        if check:
            ball.move()
            for i in figure_list:
                i.draw()
            if not ball.iscatched() and pg.mouse.get_focused():
                screen.blit(cursor.image, cursor.rect)
                m_coords = tuple(pg.mouse.get_pos())
                cursor.rect.x = m_coords[0]
                cursor.rect.y = m_coords[1]
            if pg.mouse.get_focused():
                pg.display.update()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                running = False
            if event.type == pg.MOUSEBUTTONDOWN and ball.iscatched():
                ball = Ball(tuple(pg.mouse.get_pos()))
                check = 1
                completed = 0
                figure_list.extend(generation(result))
                for i in figure_list:
                    i.center = (i.center[0], i.center[1] + 25)
        if ball.iscatched() and pg.mouse.get_focused():
            pg.mouse.set_visible(False)
            screen.fill(pg.Color(r, g, b,))
            font = pg.font.Font(None, 100)
            text = font.render(str(result), True, (25, 25, 25))
            screen.blit(text, (205 -  20 * len(str(result)), 200))
            font = pg.font.Font(None, 30)
            text = font.render(str(ball_power), True, (255, 0, 0))
            screen.blit(text, (8, 476))
            m_coords = tuple(pg.mouse.get_pos())
            for i in figure_list:
                i.draw()
            pg.draw.line(screen, pg.Color((255, 255, 0,)), [0, 437], [400, 437], 5)
            pg.draw.line(screen, pg.Color((255, 0, 0,)), m_coords, [200, 500], 5)
            screen.blit(cursor.image, cursor.rect)
            pg.display.update()
            m_coords = tuple(pg.mouse.get_pos())
            cursor.rect.x = m_coords[0]
            cursor.rect.y = m_coords[1]
        #Экран, если идёт сборка, а пользователь увёл мышку
        elif not pg.mouse.get_focused() and not ball.iscatched():
            pg.mouse.set_visible(False)
            screen.fill(pg.Color(r, g, b,))
            font = pg.font.SysFont('OCR A Extended', 72)
            text = font.render('BRICKSHOT', True, (255, 255, 0))
            screen.blit(text, (5, 200))
            font = pg.font.SysFont('OCR A Extended', 24)
            text = font.render('running...', True, (255, 255, 0))
            screen.blit(text, (130, 270))
        #Экран, если мяч собран, а пользователь увёл мышку
        elif not pg.mouse.get_focused() and ball.iscatched():
            pg.mouse.set_visible(True)
            screen.fill(pg.Color(r, g, b,))
            font = pg.font.SysFont('OCR A Extended', 72)
            text = font.render('BRICKSHOT', True, (0, 255, 0))
            screen.blit(text, (5, 200))
            font = pg.font.SysFont('OCR A Extended', 24)
            text = font.render('completed', True, (0, 255, 0))
            screen.blit(text, (130, 270))
        if ball.iscatched() and not completed:
            r = 255
            g = 255
            b = 255
            result += 1
            completed = 1
            image = load_image(['Tree_cursor.png', 'Custom_cursor1.png',
                                'Telegram_cursor.png', 'Custom_cursor2.png',
                                'Custom_cursor3.png', 'Custom_cursor4.png',
                                'Custom_cursor5.png', 'Custom_cursor6.png',
                                'Custom_cursor7.png', 'Custom_cursor8.png'][randint(0, 9)]).convert_alpha()

            cursor = Sprite(image)
            sound = pg.mixer.Sound('Complete_sound.mp3')
            if lines[0].split()[1] == 'on':
                pg.mixer.Channel(3).play(sound)
        for i in figure_list:
            if i.center[1] >= 375:
                running = False
                break
        pg.display.flip()
        clock.tick(240)
    pg.quit()
    start_game = 0
